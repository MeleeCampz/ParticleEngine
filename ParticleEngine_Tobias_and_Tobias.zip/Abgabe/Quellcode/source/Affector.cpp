#include "..\include\Affector.h"


Affector::Affector(cml::vector3f position):
	SelectableObject(position)
{
}


Affector::~Affector(void)
{
}
